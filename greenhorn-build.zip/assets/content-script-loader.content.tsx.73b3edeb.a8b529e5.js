(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content.tsx.73b3edeb.js")
    );
  })().catch(console.error);

})();
