## OS information
OS Name:	Microsoft Windows 11 Home Single Language
Version:	10.0.22621 Build 22621

## environment requirements
node: v18.12.1
npm: 8.19.2

## build instructions
npm install yarn
yarn
yarn build